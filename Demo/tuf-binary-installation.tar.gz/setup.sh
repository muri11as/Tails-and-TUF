#!/bin/bash
#########################################################################
#Author: Toan Nguyen
#Date: Nov 17, 2013
#Decription: A script that will install TUF 0.7.5 binary in Tails 0.21
#########################################################################
clear
echo Begin installing pip-1.4.1...
cd pip-1.4.1
sudo python setup.py install
echo pip1.4 installed
echo Begin installing setuptools-1.4...
cd ..
cd setuptools-1.4
sudo python setup.py install
echo setuptools-1.4 installed
echo Begin installing wheel-0.22.0...
cd ..
cd wheel-0.22.0
sudo python setup.py install
echo wheel-0.22.0 installed
echo Begin installing TUF-0.7.5...
cd ..
sudo pip install --use-wheel --no-index --find-links="./" tuf
echo TUF-0.7.5 installed
echo Changing permissions for TUF to work with normal user...
sudo chmod -R 755 /usr/local/lib/python2.6/dist-packages/tuf
sudo chmod -R 755 /usr/local/lib/python2.6/dist-packages/tuf-0.7.5.dist-info
sudo chmod -R 755 /usr/local/lib/python2.6/dist-packages/Crypto
sudo chmod -R 755 /usr/local/lib/python2.6/dist-packages/ed25519
sudo chmod -R 755 /usr/local/lib/python2.6/dist-packages/pycrypto-2.6.1.dist-info
